﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUpService
{
    public static class Trace
    {
        static string filePath = "C:\\Log\\FuelMuleFillUpTraceLogger.txt";
        public static void TraceService(string Contents)
        {
            try
            {
                // string filePath = "C:\\Log\\VintageTraceLogger.txt";
                //if(!File.Exists(filePath))
                //{
                //    File.Create(filePath)
                //}
                File.WriteAllText(filePath, Contents + " on : " + DateTime.Now);
                //set up a filestream
                //FileStream fs = new FileStream("C:\\VintageTraceLogger.txt", FileMode.OpenOrCreate, FileAccess.Write);
                //set up a streamwriter for adding text
                // StreamWriter sw = new StreamWriter(fs);

                //find the end of the underlying filestream
                //sw.BaseStream.Seek(0, SeekOrigin.End);

                //add the text
                // sw.WriteLine();
                // sw.WriteLine(Contents + " on : " + DateTime.Now);

                //add the text to the underlying filestream
                // sw.Flush();

                //close the writer
                // sw.Close();
            }
            catch (Exception ex)
            {
                //Trace.TraceService("Error in TraceService() is " + ex.Message);

            }
        }
        public static void ClearTraceContents(string Contents)
        {
            try
            {
                //Clear All Contents

                File.WriteAllText(filePath, string.Empty);
            }
            catch (Exception ex)
            {
                //Trace.TraceService("Error in ClearTraceContents() is " + ex.Message);
            }
        }
    }

}
