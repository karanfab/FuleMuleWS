﻿using FuelMuleFillUpService.FuelMuleFillUpAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Timers;

namespace FuelMuleFillUpService
{
    public partial class Service1 : ServiceBase
    {
        Timer timer;
        DateTime _scheduleTime = DateTime.Today.AddDays(1).AddHours(2);
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                //add this line to text file during start of service 3600000
                Trace.TraceService("Start service is called on: " + DateTime.Now);
                double interval = Convert.ToDouble(ConfigurationManager.AppSettings["ServiceInterval"].ToString());
                //handle Elapsed event
                timer = new Timer();
                timer.Enabled = true;
                timer.Interval = interval;
                Trace.TraceService("Start service intreval  is called on: " + timer.Interval);
                timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
                // Execute tasks every day  (hour * Min * sec * milisec)
                //enabling the timer
                Trace.TraceService("start service is excuted in  successfully. on: " + DateTime.Now);
            }
            catch (Exception ex)
            {
                Trace.TraceService(" Error start service on OnStart()  is -" + ex.Message);
            }
        }

        public void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            try
            {
                Trace.TraceService(" OnElapsedTime() in is called successfully");
                FuleMuleWebAPI fuleMuleWebApi = new FuleMuleWebAPI();
                Trace.ClearTraceContents("");

                fuleMuleWebApi.UpdateSataus();
                fuleMuleWebApi.CreateAuthirizePayment();

                if (timer.Interval != 24 * 60 * 60 * 1000)
                {
                    timer.Interval = 24 * 60 * 60 * 1000;
                }
                Trace.TraceService("OnElapsedTime() is executed successfully on :" + DateTime.Now);
            }
            catch (Exception ex)
            {
                Trace.TraceService("Error in OnElapsedTime is " + ex.Message);
            }
        }

        protected override void OnStop()
        {
            try
            {
                Trace.TraceService("OnStop() is called successfully");
                timer.Enabled = false;
                Trace.TraceService("stopping service is excuted successfully.");
            }
            catch (Exception ex)
            {
                Trace.TraceService(" Error stopping service is -" + ex.Message);
            }
        }


    }
}




