﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUpService.FuelMuleFillUpAPI
{
   public  class FuleMuleWebAPI
    {
        public void UpdateSataus()
        {
            var url = ConfigurationManager.AppSettings["UpdateSataus"];
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.UseDefaultCredentials = true;
            request.Method = "GET";
            request.ContentType = "application/json";
            request.AllowAutoRedirect = true;
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                var result = new StreamReader(response.GetResponseStream());
                var Output = JsonConvert.DeserializeObject<FuelMuleFillUpService.ResponseModel.ResponseModel>(result.ReadToEnd());
                if (Output.StatusCode == (int)HttpStatusCode.OK)
                {
                    Trace.TraceService("update order status is executed successfully on :" + DateTime.Now);
                }
                else
                {
                    Trace.TraceService("update order status is executed failed on :" + DateTime.Now);
                }
            }
        }
        public void CreateAuthirizePayment()
        {
            var url = ConfigurationManager.AppSettings["CreateAuthirizePayment"];
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.UseDefaultCredentials = true;
            request.Method = "GET";
            request.ContentType = "application/json";
            request.AllowAutoRedirect = true;
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                var result = new StreamReader(response.GetResponseStream());
                var Output = JsonConvert.DeserializeObject<FuelMuleFillUpService.ResponseModel.ResponseModel>(result.ReadToEnd());
                if (Output.StatusCode == (int)HttpStatusCode.OK)
                {
                    Trace.TraceService("update order status is executed successfully on :" + DateTime.Now);
                }
                else
                {
                    Trace.TraceService("update order status is executed failed on :" + DateTime.Now);
                }
            }
        }
    }
}
